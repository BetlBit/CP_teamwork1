import React from 'react';
import { Collaborations } from './Collaborations';
import { HiPage } from './HiPage';
import { Navbar } from './Navbar';
import { Product } from './Product';
import { Footer } from './Footer';
import {useState} from 'react'
import { themes, ThemeContext } from "./ThemeContext";


function App() {
  const [theme, setTheme] = useState(themes.light)
  const handler = () => {
    setTheme((prevTheme)=> prevTheme === themes.light? themes.dark: themes.light)
  }
    return (
    <div>
      <button onClick={()=> handler()}>Клац</button>
      <ThemeContext.Provider value = {theme}>
      <Navbar />
      <HiPage />
      <Collaborations />
      <Product />
      <Footer />
      </ThemeContext.Provider>
    </div>
  );
}

export default App;
