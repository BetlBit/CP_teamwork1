import React from "react"

export const themes = {
    light: {
        background: 'rgb(235, 217, 253)',
        color: '#000000'    },
    dark:  {
        background: 'rgb(71, 60, 83)',
        color: '#F0F8FF'
    }
};
export const themes2 = {
    light: {
        background: 'rgb(235, 217, 253)',
        color: '#000000'    },
    dark:  {
        background: 'rgb(71, 60, 83)',
        color: '#F0F8FF'
    }
};

export const ThemeContext = React.createContext(themes.light)
export const ThemeContext1 = React.createContext(themes2.light)